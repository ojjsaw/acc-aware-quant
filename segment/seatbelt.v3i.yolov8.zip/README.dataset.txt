# seatbelt > 2024-06-13 7:34am
https://universe.roboflow.com/fyp-vf529/seatbelt-tw61a

Provided by a Roboflow user
License: CC BY 4.0


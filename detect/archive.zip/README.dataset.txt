# Chess Board Detection > 2023-03-23 8:33pm
https://universe.roboflow.com/tutorial-knlj8/chess-board-detection-uuppk

Provided by a Roboflow user
License: CC BY 4.0

